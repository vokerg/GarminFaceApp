import Toybox.ActivityMonitor;
import Toybox.Graphics;
import Toybox.Lang;
import Toybox.System;
import Toybox.Time;
import Toybox.Time.Gregorian;
import Toybox.WatchUi;
import Toybox.Weather;

/*
 * SegmentWeekFaceView
 *
 * This watch face is a reinterpretation of the colourful digital design the
 * user provided.  It features a large seven‑segment style time display
 * rendered entirely with vector primitives and overlaid with a subtle
 * cross‑hatch grid.  Above the time you will find the current
 * temperature, dew point delta and feels like temperature along with the
 * weather condition code.  Below the time, a row of metrics shows the
 * weekly running distance, the current heart rate and the weekly cycling
 * distance.  A second row displays the current step count with a foot
 * icon.  A final strip at the bottom shows the day of week, date and
 * relative humidity.  Colours are chosen to remain vibrant on a 64‑colour
 * MIP display.  Weekly distances are approximated using the sum of
 * ActivityMonitor history since sport‑specific splits are not exposed to
 * watch faces【749974441693871†L419-L432】.
 */
class SegmentWeekFaceView extends WatchUi.WatchFace {

    // Colour palette tuned for fenix MIP devices.  Digits are a bright
    // violet, accents cyan and orange, and supporting text light grey.  A
    // dark blue grid overlays the time to evoke the mosaic pattern of the
    // reference design.
    private var COLOR_DIGIT   = 0xC678D8;
    private var COLOR_HATCH   = 0x142A40;
    private var COLOR_CYAN    = 0x40C0E0;
    private var COLOR_ORANGE  = 0xFF8800;
    private var COLOR_WHITE   = Graphics.COLOR_WHITE;
    private var COLOR_LGRAY   = 0xAAAAAA;
    private var COLOR_DGRAY   = 0x666666;

    function initialize() {
        WatchFace.initialize();
    }

    function onLayout(dc as Dc) as Void {}
    function onShow() as Void {}

    /**
     * Primary drawing routine.  Gathers all needed data first, then
     * orchestrates each portion of the face to minimise overdraw.  The
     * drawing order roughly follows top to bottom on the screen.
     */
    function onUpdate(dc as Dc) as Void {
        // Clear screen to black
        dc.setColor(Graphics.COLOR_BLACK, Graphics.COLOR_BLACK);
        dc.clear();

        // Gather system and activity data up front
        var info   = ActivityMonitor.getInfo();
        var stats  = System.getSystemStats();
        var clock  = System.getClockTime();
        var now    = Time.now();
        var dateInfo = Gregorian.info(now, Time.FORMAT_MEDIUM);
        var current = ((Toybox has :Weather) && (Toybox.Weather has :getCurrentConditions)) ? Weather.getCurrentConditions() : null;
        var hrVal = getHeartRateValue();
        var runKm  = getWeeklyRunDistanceKm();
        var bikeKm = getWeeklyBikeDistanceKm();
        var steps  = (info != null && info.steps != null) ? info.steps : 0;
        var stepGoal = (info != null && info.stepGoal != null && info.stepGoal > 0) ? info.stepGoal : 10000;
        var humidity = (current != null && current.relativeHumidity != null) ? current.relativeHumidity : null;

        // Top row: weather details (temperature, dew point delta, feels like, condition code)
        drawWeatherRow(dc, current);

        // Middle: large time with hatch overlay and seconds bar
        drawLargeTime(dc, clock);

        // Metrics row: weekly run, live HR, weekly bike
        drawMetricsRow(dc, runKm, hrVal, bikeKm);

        // Steps row: step count with foot icon and simple progress bar
        drawStepsRow(dc, steps, stepGoal);

        // Date/humidity row
        drawDateRow(dc, dateInfo, humidity);
    }

    /**
     * Draw the top weather row.  The format follows the reference: e.g.
     * "21C +8  FL:21C" and below it a description like "MOSTLY CLOUDY (304)".
     * Dew point delta is computed as (temperature - dewPoint).  Feels like
     * temperature may differ from the actual temperature; both are shown
     * with the °C unit.  If weather data is unavailable, placeholders
     * are displayed.  The condition code is shown in parentheses【783421694069930†L20-L139】.
     */
    private function drawWeatherRow(dc as Dc, current) as Void {
        var topY   = 18;
        var line1  = "--  --  FL:--";
        var line2  = "-- (-- )";
        if (current != null) {
            var temp    = (current.temperature != null) ? current.temperature.toNumber().format("%d") : "--";
            var dew     = (current.dewPoint != null) ? current.dewPoint : null;
            var feels   = (current.feelsLikeTemperature != null) ? current.feelsLikeTemperature.toNumber().format("%d") : "--";
            var delta   = null;
            if (current.temperature != null && dew != null) {
                var diff = current.temperature.toFloat() - dew.toFloat();
                delta = (diff >= 0) ? "+" + diff.format("%d") : diff.format("%d");
            }
            var deltaStr = (delta != null) ? delta : "--";
            line1 = temp + "C " + deltaStr + "  FL:" + feels + "C";
            var condCode = (current.condition != null) ? current.condition.toNumber().format("%d") : "--";
            /*
             * Garmin does not provide a built‑in mapping from condition codes
             * to human readable strings.  Attempting to access properties
             * like shortPhrase or description would require checking for
             * method existence and API level support.  To keep this watch
             * face portable across devices and firmware versions, we omit
             * the descriptive text and instead display just the numeric
             * condition code in parentheses.  Developers may provide
             * their own mapping here if desired.
             */
            line2 = "(" + condCode + ")";
        }
        // Draw first line centred
        dc.setColor(COLOR_CYAN, Graphics.COLOR_TRANSPARENT);
        dc.drawText(140, topY, Graphics.FONT_XSMALL, line1, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
        // Draw second line below with grey colour
        dc.setColor(COLOR_LGRAY, Graphics.COLOR_TRANSPARENT);
        dc.drawText(140, topY + 14, Graphics.FONT_XTINY, line2, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
    }

    /**
     * Draw the large digital time (hours and minutes) using custom
     * seven‑segment rendering.  A cross‑hatch grid is drawn underneath
     * the digits to hint at the mosaic texture of the reference design.
     * A slim vertical bar on the right animates the seconds progression.
     */
    private function drawLargeTime(dc as Dc, clock) as Void {
        // Determine 24h or 12h format
        var hour = clock.hour;
        if (!System.getDeviceSettings().is24Hour) {
            hour = hour % 12;
            if (hour == 0) { hour = 12; }
        }
        var hourStr = hour.format("%02d");
        var minStr  = clock.min.format("%02d");
        var secVal  = clock.sec;
        var secStr  = secVal.format("%02d");
        // Layout parameters
        var digitW = 45;
        var digitH = 90;
        var spacing = 12;
        var totalW = digitW * 4 + spacing * 3;
        var startX = ((280 - totalW) / 2).toNumber();
        var yPos   = 55;
        // Cross‑hatch background across the entire digit area
        drawCrossHatch(dc, startX, yPos, totalW, digitH, 6);
        // Draw hour digits (two characters)
        for (var i = 0; i < 2; i++) {
            var x = startX + i * (digitW + spacing);
            drawSevenSegDigit(dc, x, yPos, digitW, digitH, hourStr.charAt(i));
        }
        // Draw minute digits
        for (var i = 0; i < 2; i++) {
            var x = startX + (2 + i) * (digitW + spacing);
            drawSevenSegDigit(dc, x, yPos, digitW, digitH, minStr.charAt(i));
        }
        // Colon separator: two small squares between hour and minute
        var colonX = startX + 2 * digitW + spacing * 1.5;
        var colonY = yPos + 28;
        dc.setColor(COLOR_ORANGE, Graphics.COLOR_TRANSPARENT);
        dc.fillRectangle(colonX - 5, colonY, 10, 10);
        dc.fillRectangle(colonX - 5, colonY + 28, 10, 10);
        // Seconds bar on the right: 60 slim segments indicating seconds progression
        drawSecondsBar(dc, startX + totalW + 8, yPos, digitH, secVal);
    }

    /**
     * Draw a seven‑segment digit.  Each digit is drawn within the
     * specified rectangle.  Only the segments relevant to the provided
     * character are filled.  Segments share consistent thickness relative
     * to digit width.  The colour is fixed to COLOR_DIGIT.
     */
    private function drawSevenSegDigit(dc as Dc, x as Number, y as Number, w as Number, h as Number, d as String) as Void {
        // Determine which segments to draw for the digit
        var segs;
        if (d == "0") { segs = [0,1,2,3,4,5]; }
        else if (d == "1") { segs = [1,2]; }
        else if (d == "2") { segs = [0,1,6,4,3]; }
        else if (d == "3") { segs = [0,1,6,2,3]; }
        else if (d == "4") { segs = [5,6,1,2]; }
        else if (d == "5") { segs = [0,5,6,2,3]; }
        else if (d == "6") { segs = [0,5,6,2,3,4]; }
        else if (d == "7") { segs = [0,1,2]; }
        else if (d == "8") { segs = [0,1,2,3,4,5,6]; }
        else if (d == "9") { segs = [0,1,2,3,5,6]; }
        else { segs = []; }
        var th = (w / 6).toNumber();
        var halfH = h / 2.0;
        // Foreground colour for segments
        dc.setColor(COLOR_DIGIT, Graphics.COLOR_TRANSPARENT);
        // Helper closure to test segment membership because Array.contains()
        // is not guaranteed on all API levels
        function segContains(idx as Number) as Boolean {
            for (var ii = 0; ii < segs.size(); ii++) {
                if (segs[ii] == idx) { return true; }
            }
            return false;
        }
        // Segment definitions
        // 0: top horizontal
        if (segContains(0)) {
            dc.fillRectangle(x + th + 1, y, w - 2 * th - 2, th);
        }
        // 1: top right
        if (segContains(1)) {
            dc.fillRectangle(x + w - th, y + th, th, halfH - th);
        }
        // 2: bottom right
        if (segContains(2)) {
            dc.fillRectangle(x + w - th, y + halfH + th / 2, th, halfH - 1.5 * th);
        }
        // 3: bottom horizontal
        if (segContains(3)) {
            dc.fillRectangle(x + th + 1, y + h - th, w - 2 * th - 2, th);
        }
        // 4: bottom left
        if (segContains(4)) {
            dc.fillRectangle(x, y + halfH + th / 2, th, halfH - 1.5 * th);
        }
        // 5: top left
        if (segContains(5)) {
            dc.fillRectangle(x, y + th, th, halfH - th);
        }
        // 6: middle horizontal
        if (segContains(6)) {
            dc.fillRectangle(x + th + 1, y + halfH - th / 2, w - 2 * th - 2, th);
        }
    }

    /**
     * Draw a cross‑hatch grid of vertical and horizontal lines over a
     * rectangular area.  Spacing controls the distance between lines.  A
     * subtle dark colour is used to allow the digits beneath to remain
     * readable.  This function does not modify the current pen width.
     */
    private function drawCrossHatch(dc as Dc, x as Number, y as Number, w as Number, h as Number, spacing as Number) as Void {
        dc.setColor(COLOR_HATCH, Graphics.COLOR_TRANSPARENT);
        // Vertical lines
        var xx = x;
        while (xx <= x + w) {
            dc.drawLine(xx, y, xx, y + h);
            xx += spacing;
        }
        // Horizontal lines
        var yy = y;
        while (yy <= y + h) {
            dc.drawLine(x, yy, x + w, yy);
            yy += spacing;
        }
    }

    /**
     * Draw a slim vertical bar indicating the current seconds value.  The bar
     * is divided into 60 equally sized segments.  Filled segments are
     * coloured orange for the first half (0‑30 seconds) and cyan for the
     * remainder.  Unfilled segments are dark grey.  The bar sits just to
     * the right of the large time digits.
     */
    private function drawSecondsBar(dc as Dc, x as Number, y as Number, height as Number, secVal as Number) as Void {
        var segH = height / 60.0;
        for (var i = 0; i < 60; i++) {
            var yPos = y + i * segH;
            if (i < secVal) {
                dc.setColor(i < 30 ? COLOR_ORANGE : COLOR_CYAN, Graphics.COLOR_TRANSPARENT);
            } else {
                dc.setColor(COLOR_DGRAY, Graphics.COLOR_TRANSPARENT);
            }
            dc.fillRectangle(x, yPos, 4, (segH - 1).toNumber());
        }
    }

    /**
     * Draw the metric row with three items: weekly running distance (in
     * kilometres), current heart rate, and weekly cycling distance.  Each
     * value is accompanied by a small label.  Values are orange when
     * present, otherwise "--".  The items are evenly spaced across the
     * width of the screen.
     */
    private function drawMetricsRow(dc as Dc, runKm, hrVal, bikeKm) as Void {
        var y = 160;
        var labels = [ "RUN WEEK", "LIVE HR", "BIKE WEEK" ];
        var values = [
            (runKm == null) ? "--" : formatDistanceKm(runKm),
            (hrVal == null) ? "--" : hrVal.toString(),
            (bikeKm == null) ? "--" : formatDistanceKm(bikeKm)
        ];
        var positions = [ 46, 140, 234 ];
        for (var i = 0; i < 3; i++) {
            // Label
            dc.setColor(COLOR_LGRAY, Graphics.COLOR_TRANSPARENT);
            dc.drawText(positions[i], y, Graphics.FONT_XTINY, labels[i], Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
            // Value below label
            dc.setColor(COLOR_ORANGE, Graphics.COLOR_TRANSPARENT);
            dc.drawText(positions[i], y + 12, Graphics.FONT_XTINY, values[i], Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
        }
    }

    /**
     * Draw the steps row containing the current step count and a foot
     * icon.  A simple horizontal progress bar beneath the number shows
     * progress toward the step goal.  The bar fills cyan and orange
     * proportionally.  If goal progress exceeds 1.0, it is clamped.
     */
    private function drawStepsRow(dc as Dc, steps as Number, goal as Number) as Void {
        var y = 188;
        var xIcon = 40;
        var xText = 70;
        var barX  = 120;
        var barW  = 130;
        var barH  = 6;
        // Foot icon
        drawFootIcon(dc, xIcon, y + 8);
        // Steps value
        dc.setColor(COLOR_ORANGE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(xText, y + 8, Graphics.FONT_XTINY, formatSteps(steps), Graphics.TEXT_JUSTIFY_LEFT | Graphics.TEXT_JUSTIFY_VCENTER);
        // Progress bar background
        dc.setColor(COLOR_DGRAY, Graphics.COLOR_TRANSPARENT);
        dc.fillRectangle(barX, y + 5, barW, barH);
        // Progress fill
        var progress = (goal > 0) ? (steps.toFloat() / goal.toFloat()) : 0.0;
        if (progress > 1.0) { progress = 1.0; }
        var fillW = barW * progress;
        // Use two colours: orange for first half and cyan for second half
        var half = barW / 2.0;
        if (fillW <= half) {
            dc.setColor(COLOR_ORANGE, Graphics.COLOR_TRANSPARENT);
            dc.fillRectangle(barX, y + 5, fillW, barH);
        } else {
            // Fill first half orange
            dc.setColor(COLOR_ORANGE, Graphics.COLOR_TRANSPARENT);
            dc.fillRectangle(barX, y + 5, half, barH);
            // Fill remaining cyan
            dc.setColor(COLOR_CYAN, Graphics.COLOR_TRANSPARENT);
            dc.fillRectangle(barX + half, y + 5, fillW - half, barH);
        }
    }

    /**
     * Draw the bottom date/humidity row.  Formats the day of week, day
     * number and month.  The humidity value is appended as a percentage
     * if available.  All text is drawn in grey.
     */
    private function drawDateRow(dc as Dc, dateInfo, humidity) as Void {
        var y = 228;
        // Day of week (short)
        var dow = dateInfo.day_of_week.toUpper();
        var dateStr = dateInfo.day.format("%02d") + " " + dateInfo.month.toUpper();
        var humStr = (humidity != null) ? humidity.toNumber().format("%d") : "--";
        // Compose string: e.g. "FRI, 30 MAY 39%"
        var full = dow + ", " + dateStr + " " + humStr;
        dc.setColor(COLOR_LGRAY, Graphics.COLOR_TRANSPARENT);
        dc.drawText(140, y, Graphics.FONT_XTINY, full, Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
    }

    /**
     * Get the latest valid heart rate sample from the heart rate history.
     * Returns null if no valid sample is available【749974441693871†L15-L33】.
     */
    private function getHeartRateValue() {
        if (!(ActivityMonitor has :getHeartRateHistory)) {
            return null;
        }
        var iter = ActivityMonitor.getHeartRateHistory(6, true);
        if (iter == null) { return null; }
        var sample = iter.next();
        while (sample != null) {
            if (sample.heartRate != null && sample.heartRate != ActivityMonitor.INVALID_HR_SAMPLE) {
                return sample.heartRate;
            }
            sample = iter.next();
        }
        return null;
    }

    /**
     * Compute the weekly running distance in kilometres by summing the
     * distance fields of the ActivityMonitor history entries.  If
     * history is unavailable, returns null【749974441693871†L419-L432】.
     */
    private function getWeeklyRunDistanceKm() {
        return getRollingDistanceKm();
    }

    /**
     * Compute the weekly cycling distance.  Sport‑specific split data is
     * not available on device, so return null.  A future version could
     * populate this via settings or a companion app.
     */
    private function getWeeklyBikeDistanceKm() {
        return null;
    }

    /**
     * Sum the distance fields of the most recent history entries.  Distances
     * are in centimetres; convert to kilometres (cm to km = /100000).  If
     * history is null, return null.
     */
    private function getRollingDistanceKm() {
        var hist = ActivityMonitor.getHistory();
        if (hist == null) { return null; }
        var cm = 0;
        for (var i = 0; i < hist.size(); i++) {
            var day = hist[i];
            if (day.distance != null) {
                cm += day.distance;
            }
        }
        return cm.toFloat() / 100000.0;
    }

    /**
     * Format a distance value in kilometres as a string with one decimal
     * place up to 99.9km and whole numbers for 100km and above.  Adds
     * the letter "K" to indicate kilometres.
     */
    private function formatDistanceKm(km as Float) as String {
        if (km >= 100.0) {
            return km.format("%.0f") + "K";
        }
        return km.format("%.1f") + "K";
    }

    /**
     * Format a steps count.  Use K suffix for thousands with one decimal
     * place.  Otherwise return the raw number.
     */
    private function formatSteps(steps as Number) as String {
        if (steps >= 1000) {
            return (steps / 1000.0).format("%.1f") + "K";
        }
        return steps.toString();
    }

    /**
     * Draw a simple foot icon composed of two circles and a few lines.  The
     * icon is white and sized relative to small text.
     */
    private function drawFootIcon(dc as Dc, x as Number, y as Number) as Void {
        dc.setColor(COLOR_WHITE, Graphics.COLOR_TRANSPARENT);
        dc.setPenWidth(1);
        dc.drawCircle(x - 4, y - 2, 3);
        dc.drawCircle(x + 3, y + 2, 3);
        dc.drawLine(x - 6, y + 4, x - 2, y + 8);
        dc.drawLine(x + 1, y + 7, x + 5, y + 11);
    }

    function onHide() as Void {}
    function onExitSleep() as Void {}
    function onEnterSleep() as Void {}
}